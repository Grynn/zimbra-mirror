#!/bin/sh

autoreconf
