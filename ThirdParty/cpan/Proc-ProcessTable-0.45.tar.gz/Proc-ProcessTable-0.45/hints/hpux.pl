symlink "os/HPUX.c", "OS.c" || die "Could not link os/HPUX.c to os/OS.c\n";
