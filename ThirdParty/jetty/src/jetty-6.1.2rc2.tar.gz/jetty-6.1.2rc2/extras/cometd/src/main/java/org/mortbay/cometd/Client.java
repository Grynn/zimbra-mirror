// ========================================================================
// Copyright 2006 Mort Bay Consulting Pty. Ltd.
// ------------------------------------------------------------------------
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at 
// http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//========================================================================

package org.mortbay.cometd;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimerTask;

import org.mortbay.log.Log;
import org.mortbay.util.LazyList;


/* ------------------------------------------------------------ */
/**
 * 
 * @author gregw
 */
public class Client
{
    private Bayeux _bayeux;
    private String _id;
    private String _type;
    private ArrayList<Map> _messages=new ArrayList<Map>();
    private int _responsesPending;
    private Object _dataFilters=null;
    private Channel _connection=null;
    private Set<Channel> _subscriptions=new HashSet<Channel>();
    private long _accessed;
    private transient TimerTask _timeout; 
    
    /* ------------------------------------------------------------ */
    Client(Bayeux bayeux, String idPrefix)
    {
        _bayeux=bayeux;
        if (idPrefix==null)
            _id=Long.toString(bayeux.getRandom(System.identityHashCode(this)^System.currentTimeMillis()),36);
        else
            _id=idPrefix+"_"+Long.toString(bayeux.getRandom(System.identityHashCode(this)^System.currentTimeMillis()),36);
    }

    /* ------------------------------------------------------------ */
    public void remove()
    {
        _bayeux.removeClient(_id);        
    }
    
    /* ------------------------------------------------------------ */
    /**
     * @param filter
     */
    public void addDataFilter(DataFilter filter)
    {
        synchronized (this)
        {
            _dataFilters=LazyList.add(_dataFilters,filter);
        }
    }
    
    /* ------------------------------------------------------------ */
    public String getConnectionType()
    {
        return _type;
    }
    
    /* ------------------------------------------------------------ */
    public String getId()
    {
        return _id;
    }
    
    /* ------------------------------------------------------------ */
    /**
     * Connect the client.
     * @return the meta Channel for the connection
     */
    public Channel connect()
    {
        synchronized(this)
        {
            String connection_id="/meta/connections/"+getId();
            _connection=_bayeux.getChannel(connection_id, true);
            _connection.addSubscriber(this);
            return _connection;
        }
    }
   
    /* ------------------------------------------------------------ */
    /**
     * @return the meta Channel for the connection or null if not connected.
     */
    public Channel getConnection()
    {
        return _connection;
    }
    
    /* ------------------------------------------------------------ */
    public boolean hasMessages()
    {
        synchronized (this)
        {
            return _messages!=null && _messages.size()>0;
        }
    }
    
    /* ------------------------------------------------------------ */
    /**
     * @param filter
     */
    public void removeDataFilter(DataFilter filter)
    {
        synchronized (this)
        {
            _dataFilters=LazyList.remove(_dataFilters,filter);
        }
    }
    
    /* ------------------------------------------------------------ */
    public List takeMessages()
    {
        synchronized (this)
        {
            if (_messages==null || _messages.size()==0)
                return null;
            List list = _messages;
            _messages=new ArrayList<Map>();
            return list;
        }
    }
       
    /* ------------------------------------------------------------ */
    public String toString()
    {
        return _id;
    }
    
    /* ------------------------------------------------------------ */
    void deliver(Client from, Channel to, Map message)
    {
        synchronized (this)
        {
            if (_connection!=null)
            {
                _messages.add(message);

                if (_responsesPending<1)
                {
                    resume();
                }
            }
        }
    }

    /* ------------------------------------------------------------ */
    /** Called by deliver to resume anything waiting on this client.
     */
    public void resume()
    {
    }
    
    
    /* ------------------------------------------------------------ */
    Object filterData(Client from, Channel to, Object data)
    {
        synchronized (this)
        {
            try
            {
                for (int f=0;f<LazyList.size(_dataFilters);f++)
                {
                    data=((DataFilter)LazyList.get(_dataFilters,f)).filter(from, to, data);
                    if (data==null)
                        return null;
                }
            }
            catch (IllegalStateException e)
            {
                Log.debug(e);
                return null;
            }
        }
        return data;
    }
    
    /* ------------------------------------------------------------ */
    int responded()
    {
        synchronized (this)
        {
            return _responsesPending--;
        }
    }

    /* ------------------------------------------------------------ */
    int responsePending()
    {
        synchronized (this)
        {
            return ++_responsesPending;
        }
    }
    
    /* ------------------------------------------------------------ */
    void setConnectionType(String type)
    {
        synchronized (this)
        {
            _type=type;
        }
    }

    /* ------------------------------------------------------------ */
    void setId(String _id)
    {
        synchronized (this)
        {
            this._id=_id;
        }
    }

    /* ------------------------------------------------------------ */
    void addSubscription(Channel channel)
    {
        synchronized (this)
        {
            _subscriptions.add(channel);
        }
    }

    /* ------------------------------------------------------------ */
    void removeSubscription(Channel channel)
    {
        synchronized (this)
        {
            _subscriptions.remove(channel);
        }
    }

    /* ------------------------------------------------------------ */
    void access()
    {
        synchronized(this)
        {
            // distribute access time in cluster
            _accessed=System.currentTimeMillis();
        
            if (_timeout!=null)
                _timeout.cancel();
            
            // a bit of a waste creating a new instance every time!
            _timeout = new TimerTask()
            {
                public void run()
                {
                    long now = System.currentTimeMillis();
                    if (_accessed+_bayeux.getClientTimeoutMs()<now)
                        remove();
                }
            };
                
            _bayeux._clientTimer.schedule(_timeout,_bayeux.getClientTimeoutMs());
                
        }
        
    }

    /* ------------------------------------------------------------ */
    void unsubscribeAll()
    {
        synchronized(this)
        {
            _messages.clear();
            for (Channel channel : new ArrayList<Channel>(_subscriptions))
            {
                channel.removeSubscriber(this);
            }
        }
    }

}