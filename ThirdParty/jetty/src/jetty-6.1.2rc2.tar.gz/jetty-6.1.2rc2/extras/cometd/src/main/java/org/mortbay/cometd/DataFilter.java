/**
 * 
 */
package org.mortbay.cometd;

/* ------------------------------------------------------------ */
/** Data Filter
 * Data filters are used to transform data as it is sent to a Channel.
 * 
 * @author gregw
 *
 */
public interface DataFilter
{
    /**
     * @param from
     * @param to TODO
     * @param data
     * @return The filtered data.
     * @throws IllegalStateException If the message should be aborted
     */
    Object filter(Client from, Channel to, Object data) throws IllegalStateException;
}
