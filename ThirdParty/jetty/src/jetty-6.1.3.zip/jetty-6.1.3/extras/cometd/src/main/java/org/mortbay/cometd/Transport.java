/**
 * 
 */
package org.mortbay.cometd;

import java.io.IOException;
import java.util.Map;
import java.util.Queue;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Transport 
{
    public void setResponse(HttpServletResponse response) throws IOException;
    
    public void send(Map<String, Object> reply) throws IOException;
    public void send(Queue<Map<String, Object>> replies) throws IOException;
    public void complete() throws IOException;
    
    public boolean isPolling();
    public void setPolling(boolean polling);
    public boolean keepAlive() throws IOException;
    
    public void setJSONCommented(boolean commented);
    public boolean isJSONCommented();
    
}