<?
// Path to perl executable
$perl_exe = "c:\\perl\\bin\\perl.exe"; 
// Path to mrtg base dir
$mrtg_path = "e:\\mrtg\\"; 
// Path to mrtg script (default install)
$mrtg_exe = $mrtg_path."bin\\mrtg";

// Path to Indexmaker script (default install)
$indexmaker_exe = $mrtg_path."bin\\indexmaker";
// Path to Cfgmaker script (default install)
$cfgmaker_exe = $mrtg_path."bin\\cfgmaker";

// Enter the path where the html file are generated
$mrtg_html_dir = "e:\\mrtg\\www\\"; 
// Enter the path where the .cfg are generated
$mrtg_config_dir = "e:\\mrtg\\conf\\"; 
// Enter the path of the Mrtg images (logo)
$mrtg_icon_dir = "/mrtg/images/";

// Admin password
$admin_password1 = "bilbao";
$admin_password2 = "mrtg";
?>