<?php

###
### Copyright (c) 2012, The OpenDKIM Project.  All rights reserved.
###

# Database configuration for REPUTE queries

# reputation database
$repute_db = "localhost";

# database user
$repute_user = "opendkim";

# database password
$repute_pwd = "opendkim";

# database name
$repute_dbname = "opendkim";

# use JSON?  if yes, set this to 1
$use_json = 0;

?>
