
#ifndef _GDLUCIDAB10_H_
#define _GDLUCIDAB10_H_ 1

/*
	This is a header file for gd font, generated using
	bdftogd version 0.51 by Jan Pazdziora, adelton@fi.muni.cz
	from bdf font
	-B&H-LucidaTypewriter-Bold-R-Normal-Sans-10-100-75-75-M-60-ISO8859-1
	at Tue Jul 13 15:36:06 1999.
	The original bdf was holding following copyright:
	"Copyright Bigelow & Holmes 1986, 1985."
 */


#include "gd.h"

extern gdFontPtr gdLucidaBold10;

#endif

