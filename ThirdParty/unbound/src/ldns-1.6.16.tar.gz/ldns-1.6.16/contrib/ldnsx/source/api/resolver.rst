Class resolver
===============

.. autoclass:: ldnsx.resolver
	:members:
	:undoc-members:
