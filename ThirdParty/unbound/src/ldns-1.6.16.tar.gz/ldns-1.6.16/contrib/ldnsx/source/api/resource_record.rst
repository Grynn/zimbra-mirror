Class resource_record
=====================

.. autoclass:: ldnsx.resource_record
	:members:
	:undoc-members:
