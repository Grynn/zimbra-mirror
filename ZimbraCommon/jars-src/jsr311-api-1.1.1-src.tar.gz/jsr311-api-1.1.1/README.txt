A REST-based API that empowers/enables developers to rapidly build Web
applications in Java that are characteristic of the best designed parts of the
Web.

Type 'ant' to build the project.
