/**
 * APIs that provide extensions to the types supported by the JAX-RS API.
 */
package javax.ws.rs.ext;