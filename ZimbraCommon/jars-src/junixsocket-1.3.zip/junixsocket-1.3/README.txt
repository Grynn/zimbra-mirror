junixsocket 1.0
Unix Domain Sockets for Java + RMI-over-AF_UNIX. 

Copyright (c) 2009, 2010 NewsClub, Christian Kohlschütter

See LICENSE.txt for licensing information.
See docs/ for the JavaDoc documentation
See http://code.google.com/p/junixsocket/ for further information.
 
