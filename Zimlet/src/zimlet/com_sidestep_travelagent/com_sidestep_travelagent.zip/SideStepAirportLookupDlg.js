function SideStepAirportLookupDlg(parent,appCtxt, parentDlg, zimlet) {
	ZmDialog.call(this, parent, null, null, "Airport Code Lookup");
	this._appCtxt = appCtxt;
	this.zimlet = zimlet;
	this.parentDlg=parentDlg;
	this.parentDlg = parentDlg;	
	var contentEl = this._createContentEl();
	var contentDiv = this._getContentDiv();
	contentDiv.appendChild(contentEl);	
}

SideStepAirportLookupDlg.prototype = new ZmDialog;
SideStepAirportLookupDlg.prototype.constructor = SideStepAirportLookupDlg;

SideStepAirportLookupDlg.prototype.toString = 
function() {
	return "SideStepAirportLookupDlg";
}

SideStepAirportLookupDlg.prototype.getSelectedAirport = 
function () {
	return this._airportSelect.getValue();
}

SideStepAirportLookupDlg.prototype._createContentEl = 
function () {
	this._airportSelect = new DwtSelect(this);
	
	var table = document.createElement("TABLE");
	table.border = 0;
	table.cellSpacing = 3;
	table.cellPadding = 0;
	var row1 = table.insertRow(table.rows.length);
	var cityLabelCell = row1.insertCell(row1.cells.length);
//	cityLabelCell.className = "Label";
	cityLabelCell.innerHTML = "Enter city and state or zip code:";
	cityLabelCell.colSpan = 2;
	var row2 = table.insertRow(table.rows.length); 
	var cityNameCell = row2.insertCell(row2.cells.length);
	this._cityField = new DwtInputField({parent:this, type:DwtInputField.STRING,
											initialValue:"", size:null, maxLen:null,
											errorIconStyle:DwtInputField.ERROR_ICON_NONE,
											validationStyle:DwtInputField.ONEXIT_VALIDATION});	
	
	cityNameCell.appendChild(this._cityField.getHtmlElement());
	var searchBtnCell = row2.insertCell(row2.cells.length);		
	var searchButton = new DwtButton(this);
	searchButton.setText("Search");
	searchButton.setToolTipContent("Click this button to find airports");
	searchButton.addSelectionListener(new AjxListener(this, this._searchButtonListener));
	searchBtnCell.appendChild(searchButton.getHtmlElement());		
									
	var row3 = table.insertRow(table.rows.length);
	var airportLabelCell = row3.insertCell(row3.cells.length);
	//airportLabelCell.className = "Label";
	airportLabelCell.innerHTML = "Airports:";	
	airportLabelCell.colSpan = 2;

	var row4 = table.insertRow(table.rows.length);
	var airportSelectCell = row4.insertCell(row4.cells.length);	
	airportSelectCell.colSpan = 2;
	airportSelectCell.appendChild(this._airportSelect.getHtmlElement());
	return table;
}

SideStepAirportLookupDlg.prototype._searchButtonListener =
function (ev) {
	var loc = this._cityField.getValue();
	var options = this.zimlet.findAirports(loc);
	var cnt = options.length;
	this._airportSelect.clearOptions();
	for(var i=0; i < cnt; i++) {
		this._airportSelect.addOption(options[i], i==0);
	}
}