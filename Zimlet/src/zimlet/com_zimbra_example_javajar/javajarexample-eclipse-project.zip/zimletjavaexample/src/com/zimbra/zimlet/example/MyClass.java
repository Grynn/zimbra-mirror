package com.zimbra.zimlet.example;

public class MyClass {


	public	static	String	getString() {
		
		return	"Some String from MyClass";
	}
}
